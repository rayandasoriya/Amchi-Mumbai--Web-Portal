-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 06, 2017 at 11:00 PM
-- Server version: 5.6.35
-- PHP Version: 7.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `ci_bootstrap_3`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_groups`
--

CREATE TABLE `admin_groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin_groups`
--

INSERT INTO `admin_groups` (`id`, `name`, `description`) VALUES
(1, 'webmaster', 'Webmaster'),
(2, 'admin', 'Administrator'),
(3, 'manager', 'Manager'),
(4, 'staff', 'Staff');

-- --------------------------------------------------------

--
-- Table structure for table `admin_login_attempts`
--

CREATE TABLE `admin_login_attempts` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`) VALUES
(1, '127.0.0.1', 'webmaster', '$2y$08$/X5gzWjesYi78GqeAv5tA.dVGBVP7C1e1PzqnYCVe5s1qhlDIPPES', NULL, NULL, NULL, NULL, NULL, NULL, 1451900190, 1502024271, 1, 'Webmaster', ''),
(2, '127.0.0.1', 'admin', '$2y$08$7Bkco6JXtC3Hu6g9ngLZDuHsFLvT7cyAxiz1FzxlX5vwccvRT7nKW', NULL, NULL, NULL, NULL, NULL, NULL, 1451900228, 1465489580, 1, 'Admin', ''),
(3, '127.0.0.1', 'manager', '$2y$08$snzIJdFXvg/rSHe0SndIAuvZyjktkjUxBXkrrGdkPy1K6r5r/dMLa', NULL, NULL, NULL, NULL, NULL, NULL, 1451900430, 1465489585, 1, 'Manager', ''),
(4, '127.0.0.1', 'staff', '$2y$08$NigAXjN23CRKllqe3KmjYuWXD5iSRPY812SijlhGeKfkrMKde9da6', NULL, NULL, NULL, NULL, NULL, NULL, 1451900439, 1465489590, 1, 'Staff', '');

-- --------------------------------------------------------

--
-- Table structure for table `admin_users_groups`
--

CREATE TABLE `admin_users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin_users_groups`
--

INSERT INTO `admin_users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 3),
(4, 4, 4);

-- --------------------------------------------------------

--
-- Table structure for table `adm_announcements`
--

CREATE TABLE `adm_announcements` (
  `ann_id` int(10) UNSIGNED NOT NULL,
  `ann_cat_id` int(10) UNSIGNED NOT NULL,
  `ann_global` tinyint(1) NOT NULL DEFAULT '0',
  `ann_headline` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `ann_description` text COLLATE utf8_unicode_ci,
  `ann_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `ann_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ann_usr_id_change` int(10) UNSIGNED DEFAULT NULL,
  `ann_timestamp_change` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adm_auto_login`
--

CREATE TABLE `adm_auto_login` (
  `atl_id` int(10) UNSIGNED NOT NULL,
  `atl_auto_login_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `atl_session_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `atl_org_id` int(10) UNSIGNED NOT NULL,
  `atl_usr_id` int(10) UNSIGNED NOT NULL,
  `atl_last_login` timestamp NULL DEFAULT NULL,
  `atl_ip_address` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `atl_number_invalid` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adm_categories`
--

CREATE TABLE `adm_categories` (
  `cat_id` int(10) UNSIGNED NOT NULL,
  `cat_org_id` int(10) UNSIGNED DEFAULT NULL,
  `cat_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `cat_name_intern` varchar(110) COLLATE utf8_unicode_ci NOT NULL,
  `cat_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cat_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `cat_system` tinyint(1) NOT NULL DEFAULT '0',
  `cat_default` tinyint(1) NOT NULL DEFAULT '0',
  `cat_sequence` smallint(6) NOT NULL,
  `cat_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `cat_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cat_usr_id_change` int(10) UNSIGNED DEFAULT NULL,
  `cat_timestamp_change` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_categories`
--

INSERT INTO `adm_categories` (`cat_id`, `cat_org_id`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_hidden`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES
(1, NULL, 'USF', 'MASTER_DATA', 'SYS_MASTER_DATA', 0, 1, 0, 1, 1, '2017-08-06 19:24:16', NULL, NULL),
(2, NULL, 'USF', 'SOCIAL_NETWORKS', 'SYS_SOCIAL_NETWORKS', 0, 0, 0, 2, 1, '2017-08-06 19:24:16', NULL, NULL),
(3, NULL, 'ROL', 'CONFIRMATION_OF_PARTICIPATION', 'SYS_CONFIRMATION_OF_PARTICIPATION', 1, 1, 0, 5, 1, '2017-08-06 19:24:16', NULL, NULL),
(4, NULL, 'USF', 'ADDIDIONAL_DATA', 'INS_ADDIDIONAL_DATA', 0, 0, 0, 3, 1, '2017-08-06 19:24:16', NULL, NULL),
(5, NULL, 'INF', 'MASTER_DATA', 'SYS_MASTER_DATA', 0, 1, 0, 1, 1, '2017-08-06 19:24:16', NULL, NULL),
(6, 1, 'ROL', 'COMMON', 'SYS_COMMON', 0, 0, 1, 1, 1, '2017-08-06 19:24:16', NULL, NULL),
(7, 1, 'ROL', 'GROUPS', 'INS_GROUPS', 0, 0, 0, 2, 1, '2017-08-06 19:24:16', NULL, NULL),
(8, 1, 'ROL', 'COURSES', 'INS_COURSES', 0, 0, 0, 3, 1, '2017-08-06 19:24:16', NULL, NULL),
(9, 1, 'ROL', 'TEAMS', 'INS_TEAMS', 0, 0, 0, 4, 1, '2017-08-06 19:24:16', NULL, NULL),
(10, 1, 'LNK', 'COMMON', 'SYS_COMMON', 0, 0, 1, 1, 1, '2017-08-06 19:24:16', NULL, NULL),
(11, 1, 'LNK', 'INTERN', 'INS_INTERN', 1, 0, 0, 2, 1, '2017-08-06 19:24:16', NULL, NULL),
(12, 1, 'ANN', 'COMMON', 'SYS_COMMON', 0, 0, 1, 1, 1, '2017-08-06 19:24:16', NULL, NULL),
(13, 1, 'ANN', 'IMPORTANT', 'SYS_IMPORTANT', 0, 0, 0, 2, 1, '2017-08-06 19:24:16', NULL, NULL),
(14, 1, 'DAT', 'COMMON', 'SYS_COMMON', 0, 0, 1, 1, 1, '2017-08-06 19:24:16', NULL, NULL),
(15, 1, 'DAT', 'TRAINING', 'INS_TRAINING', 0, 0, 0, 2, 1, '2017-08-06 19:24:16', NULL, NULL),
(16, 1, 'DAT', 'COURSES', 'INS_COURSES', 0, 0, 0, 3, 1, '2017-08-06 19:24:16', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `adm_components`
--

CREATE TABLE `adm_components` (
  `com_id` int(10) UNSIGNED NOT NULL,
  `com_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `com_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `com_name_intern` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `com_version` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `com_beta` smallint(6) NOT NULL DEFAULT '0',
  `com_update_step` int(11) NOT NULL DEFAULT '0',
  `com_timestamp_installed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_components`
--

INSERT INTO `adm_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_timestamp_installed`) VALUES
(1, 'SYSTEM', 'Admidio Core', 'CORE', '3.2.10', 0, 520, '2017-08-06 15:54:21'),
(2, 'MODULE', 'ANN_ANNOUNCEMENTS', 'ANNOUCEMENTS', '3.2.10', 0, 0, '2017-08-06 15:54:21'),
(3, 'MODULE', 'BAC_DATABASE_BACKUP', 'BACKUP', '3.2.10', 0, 0, '2017-08-06 15:54:21'),
(4, 'MODULE', 'SYS_CATEGORIES', 'CATEGORIES', '3.2.10', 0, 0, '2017-08-06 15:54:21'),
(5, 'MODULE', 'DAT_DATES', 'DATES', '3.2.10', 0, 0, '2017-08-06 15:54:21'),
(6, 'MODULE', 'DOW_DOWNLOADS', 'DOWNLOADS', '3.2.10', 0, 0, '2017-08-06 15:54:21'),
(7, 'MODULE', 'GBO_GUESTBOOK', 'GUESTBOOK', '3.2.10', 0, 0, '2017-08-06 15:54:21'),
(8, 'MODULE', 'LNK_WEBLINKS', 'LINKS', '3.2.10', 0, 0, '2017-08-06 15:54:21'),
(9, 'MODULE', 'LST_LISTS', 'LISTS', '3.2.10', 0, 0, '2017-08-06 15:54:21'),
(10, 'MODULE', 'MEM_USER_MANAGEMENT', 'MEMBERS', '3.2.10', 0, 0, '2017-08-06 15:54:21'),
(11, 'MODULE', 'SYS_MESSAGES', 'MESSAGES', '3.2.10', 0, 0, '2017-08-06 15:54:21'),
(12, 'MODULE', 'PHO_PHOTOS', 'PHOTOS', '3.2.10', 0, 0, '2017-08-06 15:54:21'),
(13, 'MODULE', 'SYS_SETTINGS', 'PREFERENCES', '3.2.10', 0, 0, '2017-08-06 15:54:21'),
(14, 'MODULE', 'PRO_PROFILE', 'PROFILE', '3.2.10', 0, 0, '2017-08-06 15:54:21'),
(15, 'MODULE', 'SYS_REGISTRATION', 'REGISTRATION', '3.2.10', 0, 0, '2017-08-06 15:54:21'),
(16, 'MODULE', 'ROL_ROLE_ADMINISTRATION', 'ROLES', '3.2.10', 0, 0, '2017-08-06 15:54:21'),
(17, 'MODULE', 'ROO_ROOM_MANAGEMENT', 'ROOMS', '3.2.10', 0, 0, '2017-08-06 15:54:21');

-- --------------------------------------------------------

--
-- Table structure for table `adm_dates`
--

CREATE TABLE `adm_dates` (
  `dat_id` int(10) UNSIGNED NOT NULL,
  `dat_cat_id` int(10) UNSIGNED NOT NULL,
  `dat_rol_id` int(10) UNSIGNED DEFAULT NULL,
  `dat_room_id` int(10) UNSIGNED DEFAULT NULL,
  `dat_global` tinyint(1) NOT NULL DEFAULT '0',
  `dat_begin` timestamp NULL DEFAULT NULL,
  `dat_end` timestamp NULL DEFAULT NULL,
  `dat_all_day` tinyint(1) NOT NULL DEFAULT '0',
  `dat_highlight` tinyint(1) NOT NULL DEFAULT '0',
  `dat_description` text COLLATE utf8_unicode_ci,
  `dat_location` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dat_country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dat_headline` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dat_max_members` int(11) NOT NULL DEFAULT '0',
  `dat_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `dat_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dat_usr_id_change` int(10) UNSIGNED DEFAULT NULL,
  `dat_timestamp_change` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_dates`
--

INSERT INTO `adm_dates` (`dat_id`, `dat_cat_id`, `dat_rol_id`, `dat_room_id`, `dat_global`, `dat_begin`, `dat_end`, `dat_all_day`, `dat_highlight`, `dat_description`, `dat_location`, `dat_country`, `dat_headline`, `dat_max_members`, `dat_usr_id_create`, `dat_timestamp_create`, `dat_usr_id_change`, `dat_timestamp_change`) VALUES
(1, 14, 4, NULL, 0, '2017-08-06 18:30:00', '2017-08-07 18:30:00', 1, 0, '<p>Test 123</p>\r\n', 'Mumbai', 'IND', 'Test1', 5, 2, '2017-08-06 19:25:31', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `adm_date_role`
--

CREATE TABLE `adm_date_role` (
  `dtr_id` int(10) UNSIGNED NOT NULL,
  `dtr_dat_id` int(10) UNSIGNED NOT NULL,
  `dtr_rol_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_date_role`
--

INSERT INTO `adm_date_role` (`dtr_id`, `dtr_dat_id`, `dtr_rol_id`) VALUES
(1, 1, NULL),
(2, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `adm_files`
--

CREATE TABLE `adm_files` (
  `fil_id` int(10) UNSIGNED NOT NULL,
  `fil_fol_id` int(10) UNSIGNED NOT NULL,
  `fil_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fil_description` text COLLATE utf8_unicode_ci,
  `fil_locked` tinyint(1) NOT NULL DEFAULT '0',
  `fil_counter` int(11) DEFAULT NULL,
  `fil_usr_id` int(10) UNSIGNED DEFAULT NULL,
  `fil_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adm_folders`
--

CREATE TABLE `adm_folders` (
  `fol_id` int(10) UNSIGNED NOT NULL,
  `fol_org_id` int(10) UNSIGNED NOT NULL,
  `fol_fol_id_parent` int(10) UNSIGNED DEFAULT NULL,
  `fol_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `fol_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fol_description` text COLLATE utf8_unicode_ci,
  `fol_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fol_locked` tinyint(1) NOT NULL DEFAULT '0',
  `fol_public` tinyint(1) NOT NULL DEFAULT '0',
  `fol_usr_id` int(10) UNSIGNED DEFAULT NULL,
  `fol_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_folders`
--

INSERT INTO `adm_folders` (`fol_id`, `fol_org_id`, `fol_fol_id_parent`, `fol_type`, `fol_name`, `fol_description`, `fol_path`, `fol_locked`, `fol_public`, `fol_usr_id`, `fol_timestamp`) VALUES
(1, 1, NULL, 'DOWNLOAD', 'download_nomura_ngo', NULL, '/adm_my_files', 0, 1, 1, '2017-08-06 19:24:16');

-- --------------------------------------------------------

--
-- Table structure for table `adm_guestbook`
--

CREATE TABLE `adm_guestbook` (
  `gbo_id` int(10) UNSIGNED NOT NULL,
  `gbo_org_id` int(10) UNSIGNED NOT NULL,
  `gbo_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `gbo_text` text COLLATE utf8_unicode_ci NOT NULL,
  `gbo_email` varchar(254) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gbo_homepage` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gbo_ip_address` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `gbo_locked` tinyint(1) NOT NULL DEFAULT '0',
  `gbo_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `gbo_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gbo_usr_id_change` int(10) UNSIGNED DEFAULT NULL,
  `gbo_timestamp_change` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adm_guestbook_comments`
--

CREATE TABLE `adm_guestbook_comments` (
  `gbc_id` int(10) UNSIGNED NOT NULL,
  `gbc_gbo_id` int(10) UNSIGNED NOT NULL,
  `gbc_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `gbc_text` text COLLATE utf8_unicode_ci NOT NULL,
  `gbc_email` varchar(254) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gbc_ip_address` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `gbc_locked` tinyint(1) NOT NULL DEFAULT '0',
  `gbc_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `gbc_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gbc_usr_id_change` int(10) UNSIGNED DEFAULT NULL,
  `gbc_timestamp_change` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adm_ids`
--

CREATE TABLE `adm_ids` (
  `ids_usr_id` int(10) UNSIGNED NOT NULL,
  `ids_reference_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adm_invent`
--

CREATE TABLE `adm_invent` (
  `inv_id` int(10) UNSIGNED NOT NULL,
  `inv_photo` blob,
  `inv_text` text COLLATE utf8_unicode_ci,
  `inv_for_loan` tinyint(1) NOT NULL DEFAULT '0',
  `inv_last_lent` timestamp NULL DEFAULT NULL,
  `inv_usr_id_lent` int(10) UNSIGNED DEFAULT NULL,
  `inv_lent_until` timestamp NULL DEFAULT NULL,
  `inv_number_lent` int(11) NOT NULL DEFAULT '0',
  `inv_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `inv_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `inv_usr_id_change` int(10) UNSIGNED DEFAULT NULL,
  `inv_timestamp_change` timestamp NULL DEFAULT NULL,
  `inv_valid` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adm_invent_data`
--

CREATE TABLE `adm_invent_data` (
  `ind_id` int(10) UNSIGNED NOT NULL,
  `ind_itm_id` int(10) UNSIGNED NOT NULL,
  `ind_inf_id` int(10) UNSIGNED NOT NULL,
  `ind_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adm_invent_fields`
--

CREATE TABLE `adm_invent_fields` (
  `inf_id` int(10) UNSIGNED NOT NULL,
  `inf_cat_id` int(10) UNSIGNED NOT NULL,
  `inf_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `inf_name_intern` varchar(110) COLLATE utf8_unicode_ci NOT NULL,
  `inf_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `inf_description` text COLLATE utf8_unicode_ci,
  `inf_value_list` text COLLATE utf8_unicode_ci,
  `inf_system` tinyint(1) NOT NULL DEFAULT '0',
  `inf_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `inf_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `inf_mandatory` tinyint(1) NOT NULL DEFAULT '0',
  `inf_sequence` smallint(6) NOT NULL,
  `inf_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `inf_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `inf_usr_id_change` int(10) UNSIGNED DEFAULT NULL,
  `inf_timestamp_change` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_invent_fields`
--

INSERT INTO `adm_invent_fields` (`inf_id`, `inf_cat_id`, `inf_type`, `inf_name_intern`, `inf_name`, `inf_description`, `inf_value_list`, `inf_system`, `inf_disabled`, `inf_hidden`, `inf_mandatory`, `inf_sequence`, `inf_usr_id_create`, `inf_timestamp_create`, `inf_usr_id_change`, `inf_timestamp_change`) VALUES
(1, 5, 'TEXT', 'ITEM_NAME', 'SYS_ITEMNAME', NULL, NULL, 1, 1, 0, 1, 1, 1, '2017-08-06 19:24:16', NULL, NULL),
(2, 5, 'NUMBER', 'ROOM_ID', 'SYS_ROOM', NULL, NULL, 1, 1, 0, 1, 2, 1, '2017-08-06 19:24:16', NULL, NULL),
(3, 5, 'NUMBER', 'PRICE', 'SYS_QUANTITY', NULL, NULL, 0, 0, 0, 0, 3, 1, '2017-08-06 19:24:16', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `adm_links`
--

CREATE TABLE `adm_links` (
  `lnk_id` int(10) UNSIGNED NOT NULL,
  `lnk_cat_id` int(10) UNSIGNED NOT NULL,
  `lnk_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lnk_description` text COLLATE utf8_unicode_ci,
  `lnk_url` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `lnk_counter` int(11) NOT NULL DEFAULT '0',
  `lnk_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `lnk_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lnk_usr_id_change` int(10) UNSIGNED DEFAULT NULL,
  `lnk_timestamp_change` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adm_lists`
--

CREATE TABLE `adm_lists` (
  `lst_id` int(10) UNSIGNED NOT NULL,
  `lst_org_id` int(10) UNSIGNED NOT NULL,
  `lst_usr_id` int(10) UNSIGNED NOT NULL,
  `lst_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lst_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lst_global` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_lists`
--

INSERT INTO `adm_lists` (`lst_id`, `lst_org_id`, `lst_usr_id`, `lst_name`, `lst_timestamp`, `lst_global`) VALUES
(1, 1, 1, 'Address list', '2017-08-06 19:24:16', 1),
(2, 1, 1, 'Phone list', '2017-08-06 19:24:16', 1),
(3, 1, 1, 'Contact information', '2017-08-06 19:24:16', 1),
(4, 1, 1, 'Membership', '2017-08-06 19:24:16', 1);

-- --------------------------------------------------------

--
-- Table structure for table `adm_list_columns`
--

CREATE TABLE `adm_list_columns` (
  `lsc_id` int(10) UNSIGNED NOT NULL,
  `lsc_lst_id` int(10) UNSIGNED NOT NULL,
  `lsc_number` smallint(6) NOT NULL,
  `lsc_usf_id` int(10) UNSIGNED DEFAULT NULL,
  `lsc_special_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lsc_sort` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lsc_filter` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_list_columns`
--

INSERT INTO `adm_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES
(1, 1, 1, 1, NULL, 'ASC', NULL),
(2, 1, 2, 2, NULL, 'ASC', NULL),
(3, 1, 3, 10, NULL, NULL, NULL),
(4, 1, 4, 3, NULL, NULL, NULL),
(5, 1, 5, 4, NULL, NULL, NULL),
(6, 1, 6, 5, NULL, NULL, NULL),
(7, 2, 1, 1, NULL, 'ASC', NULL),
(8, 2, 2, 2, NULL, 'ASC', NULL),
(9, 2, 3, 7, NULL, NULL, NULL),
(10, 2, 4, 8, NULL, NULL, NULL),
(11, 2, 5, 12, NULL, NULL, NULL),
(12, 2, 6, 9, NULL, NULL, NULL),
(13, 3, 1, 1, NULL, 'ASC', NULL),
(14, 3, 2, 2, NULL, 'ASC', NULL),
(15, 3, 3, 10, NULL, NULL, NULL),
(16, 3, 4, 3, NULL, NULL, NULL),
(17, 3, 5, 4, NULL, NULL, NULL),
(18, 3, 6, 5, NULL, NULL, NULL),
(19, 3, 7, 7, NULL, NULL, NULL),
(20, 3, 8, 8, NULL, NULL, NULL),
(21, 3, 9, 12, NULL, NULL, NULL),
(22, 4, 1, 1, NULL, 'ASC', NULL),
(23, 4, 2, 2, NULL, 'ASC', NULL),
(24, 4, 3, 10, NULL, NULL, NULL),
(25, 4, 4, NULL, 'mem_begin', NULL, NULL),
(26, 4, 5, NULL, 'mem_end', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `adm_members`
--

CREATE TABLE `adm_members` (
  `mem_id` int(10) UNSIGNED NOT NULL,
  `mem_rol_id` int(10) UNSIGNED NOT NULL,
  `mem_usr_id` int(10) UNSIGNED NOT NULL,
  `mem_begin` date NOT NULL,
  `mem_end` date NOT NULL DEFAULT '9999-12-31',
  `mem_leader` tinyint(1) NOT NULL DEFAULT '0',
  `mem_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `mem_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `mem_usr_id_change` int(10) UNSIGNED DEFAULT NULL,
  `mem_timestamp_change` timestamp NULL DEFAULT NULL,
  `mem_approved` int(10) UNSIGNED DEFAULT NULL,
  `mem_comment` varchar(4000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mem_count_guests` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_members`
--

INSERT INTO `adm_members` (`mem_id`, `mem_rol_id`, `mem_usr_id`, `mem_begin`, `mem_end`, `mem_leader`, `mem_usr_id_create`, `mem_timestamp_create`, `mem_usr_id_change`, `mem_timestamp_change`, `mem_approved`, `mem_comment`, `mem_count_guests`) VALUES
(1, 1, 2, '2017-08-07', '9999-12-31', 0, 1, '2017-08-06 19:24:16', NULL, NULL, NULL, NULL, 0),
(2, 2, 2, '2017-08-07', '9999-12-31', 0, 1, '2017-08-06 19:24:16', NULL, NULL, NULL, NULL, 0),
(3, 2, 3, '2017-08-07', '9999-12-31', 0, 2, '2017-08-06 19:33:12', NULL, NULL, NULL, NULL, 0),
(4, 2, 5, '2017-08-07', '9999-12-31', 0, 2, '2017-08-06 19:40:43', NULL, NULL, NULL, NULL, 0),
(5, 4, 5, '2017-08-07', '9999-12-31', 0, 5, '2017-08-06 19:43:05', NULL, NULL, NULL, NULL, 0),
(6, 4, 2, '2017-08-07', '9999-12-31', 0, 2, '2017-08-07 00:20:46', NULL, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `adm_messages`
--

CREATE TABLE `adm_messages` (
  `msg_id` int(10) UNSIGNED NOT NULL,
  `msg_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `msg_subject` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `msg_usr_id_sender` int(10) UNSIGNED NOT NULL,
  `msg_usr_id_receiver` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `msg_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `msg_read` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adm_messages_content`
--

CREATE TABLE `adm_messages_content` (
  `msc_id` int(10) UNSIGNED NOT NULL,
  `msc_msg_id` int(10) UNSIGNED NOT NULL,
  `msc_part_id` int(10) UNSIGNED NOT NULL,
  `msc_usr_id` int(10) UNSIGNED DEFAULT NULL,
  `msc_message` text COLLATE utf8_unicode_ci NOT NULL,
  `msc_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adm_organizations`
--

CREATE TABLE `adm_organizations` (
  `org_id` int(10) UNSIGNED NOT NULL,
  `org_longname` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `org_shortname` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `org_org_id_parent` int(10) UNSIGNED DEFAULT NULL,
  `org_homepage` varchar(60) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_organizations`
--

INSERT INTO `adm_organizations` (`org_id`, `org_longname`, `org_shortname`, `org_org_id_parent`, `org_homepage`) VALUES
(1, 'Nomura', 'Nomura NGO', NULL, 'http://localhost:8888');

-- --------------------------------------------------------

--
-- Table structure for table `adm_photos`
--

CREATE TABLE `adm_photos` (
  `pho_id` int(10) UNSIGNED NOT NULL,
  `pho_org_id` int(10) UNSIGNED NOT NULL,
  `pho_quantity` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `pho_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `pho_begin` date NOT NULL,
  `pho_end` date NOT NULL,
  `pho_photographers` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pho_locked` tinyint(1) NOT NULL DEFAULT '0',
  `pho_pho_id_parent` int(10) UNSIGNED DEFAULT NULL,
  `pho_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `pho_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pho_usr_id_change` int(10) UNSIGNED DEFAULT NULL,
  `pho_timestamp_change` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adm_preferences`
--

CREATE TABLE `adm_preferences` (
  `prf_id` int(10) UNSIGNED NOT NULL,
  `prf_org_id` int(10) UNSIGNED NOT NULL,
  `prf_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `prf_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_preferences`
--

INSERT INTO `adm_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES
(1, 1, 'enable_rss', '1'),
(2, 1, 'enable_auto_login', '1'),
(3, 1, 'default_country', 'IND'),
(4, 1, 'logout_minutes', '20'),
(5, 1, 'homepage_logout', 'adm_program/index.php'),
(6, 1, 'homepage_login', 'adm_program/index.php'),
(7, 1, 'theme', 'modern'),
(8, 1, 'enable_password_recovery', '1'),
(9, 1, 'system_show_create_edit', '1'),
(10, 1, 'system_currency', 'Rs'),
(11, 1, 'system_date', 'd.m.Y'),
(12, 1, 'system_js_editor_enabled', '1'),
(13, 1, 'system_js_editor_color', '#96c4cb'),
(14, 1, 'system_language', 'en'),
(15, 1, 'system_organization_select', '0'),
(16, 1, 'system_search_similar', '1'),
(17, 1, 'system_time', 'H:i'),
(18, 1, 'password_min_strength', '1'),
(19, 1, 'system_browser_update_check', '0'),
(20, 1, 'system_hashing_cost', '11'),
(21, 1, 'registration_mode', '1'),
(22, 1, 'enable_registration_captcha', '1'),
(23, 1, 'enable_registration_admin_mail', '1'),
(24, 1, 'mail_send_method', 'phpmail'),
(25, 1, 'mail_bcc_count', '50'),
(26, 1, 'mail_recipients_with_roles', '0'),
(27, 1, 'mail_character_encoding', 'utf-8'),
(28, 1, 'mail_smtp_host', ''),
(29, 1, 'mail_smtp_auth', '1'),
(30, 1, 'mail_smtp_port', '25'),
(31, 1, 'mail_smtp_secure', ''),
(32, 1, 'mail_smtp_authentication_type', 'LOGIN'),
(33, 1, 'mail_smtp_user', ''),
(34, 1, 'mail_smtp_password', ''),
(35, 1, 'enable_system_mails', '1'),
(36, 1, 'email_administrator', 'rajkotraja99@gmail.com'),
(37, 1, 'enable_email_notification', '0'),
(38, 1, 'captcha_type', 'pic'),
(39, 1, 'captcha_fonts', 'AHGBold.ttf'),
(40, 1, 'captcha_width', '215'),
(41, 1, 'captcha_lines_numbers', '5'),
(42, 1, 'captcha_perturbation', '0.75'),
(43, 1, 'captcha_background_image', ''),
(44, 1, 'captcha_background_color', '#B6D6DB'),
(45, 1, 'captcha_text_color', '#707070'),
(46, 1, 'captcha_line_color', '#707070'),
(47, 1, 'captcha_charset', '23456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxy'),
(48, 1, 'captcha_signature', ''),
(49, 1, 'enable_announcements_module', '1'),
(50, 1, 'announcements_per_page', '10'),
(51, 1, 'members_users_per_page', '25'),
(52, 1, 'members_days_field_history', '365'),
(53, 1, 'members_show_all_users', '1'),
(54, 1, 'members_enable_user_relations', '1'),
(55, 1, 'enable_download_module', '0'),
(56, 1, 'max_file_upload_size', '3'),
(57, 1, 'enable_photo_module', '0'),
(58, 1, 'photo_show_mode', '1'),
(59, 1, 'photo_albums_per_page', '10'),
(60, 1, 'photo_save_scale', '640'),
(61, 1, 'photo_thumbs_page', '16'),
(62, 1, 'photo_thumbs_scale', '160'),
(63, 1, 'photo_show_width', '640'),
(64, 1, 'photo_show_height', '400'),
(65, 1, 'photo_image_text', '© localhost'),
(66, 1, 'photo_image_text_size', '40'),
(67, 1, 'photo_keep_original', '0'),
(68, 1, 'photo_download_enabled', '0'),
(69, 1, 'enable_guestbook_module', '1'),
(70, 1, 'guestbook_entries_per_page', '10'),
(71, 1, 'enable_guestbook_captcha', '1'),
(72, 1, 'flooding_protection_time', '60'),
(73, 1, 'enable_gbook_comments4all', '0'),
(74, 1, 'enable_intial_comments_loading', '0'),
(75, 1, 'enable_guestbook_moderation', '0'),
(76, 1, 'lists_roles_per_page', '10'),
(77, 1, 'lists_members_per_page', '25'),
(78, 1, 'lists_hide_overview_details', '0'),
(79, 1, 'lists_default_configuration', '1'),
(80, 1, 'enable_mail_module', '1'),
(81, 1, 'enable_pm_module', '1'),
(82, 1, 'enable_chat_module', '0'),
(83, 1, 'enable_mail_captcha', '1'),
(84, 1, 'mail_max_receiver', '10'),
(85, 1, 'mail_show_former', '1'),
(86, 1, 'mail_into_to', '0'),
(87, 1, 'max_email_attachment_size', '1'),
(88, 1, 'mail_sendmail_address', ''),
(89, 1, 'mail_sendmail_name', ''),
(90, 1, 'mail_html_registered_users', '1'),
(91, 1, 'mail_delivery_confirmation', '0'),
(92, 1, 'enable_ecard_module', '0'),
(93, 1, 'ecard_thumbs_scale', '250'),
(94, 1, 'ecard_card_picture_width', '400'),
(95, 1, 'ecard_card_picture_height', '250'),
(96, 1, 'ecard_template', 'postcard.tpl'),
(97, 1, 'profile_log_edit_fields', '1'),
(98, 1, 'profile_show_map_link', '1'),
(99, 1, 'profile_show_roles', '1'),
(100, 1, 'profile_show_former_roles', '1'),
(101, 1, 'profile_show_extern_roles', '1'),
(102, 1, 'profile_photo_storage', '0'),
(103, 1, 'enable_dates_module', '1'),
(104, 1, 'dates_per_page', '10'),
(105, 1, 'dates_view', 'detail'),
(106, 1, 'dates_show_map_link', '1'),
(107, 1, 'dates_show_rooms', '0'),
(108, 1, 'enable_dates_ical', '1'),
(109, 1, 'dates_ical_days_past', '30'),
(110, 1, 'dates_ical_days_future', '365'),
(111, 1, 'enable_weblinks_module', '0'),
(112, 1, 'weblinks_per_page', '0'),
(113, 1, 'weblinks_redirect_seconds', '10'),
(114, 1, 'weblinks_target', '_blank'),
(115, 1, 'enable_inventory_module', '0');

-- --------------------------------------------------------

--
-- Table structure for table `adm_registrations`
--

CREATE TABLE `adm_registrations` (
  `reg_id` int(10) UNSIGNED NOT NULL,
  `reg_org_id` int(10) UNSIGNED NOT NULL,
  `reg_usr_id` int(10) UNSIGNED NOT NULL,
  `reg_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adm_roles`
--

CREATE TABLE `adm_roles` (
  `rol_id` int(10) UNSIGNED NOT NULL,
  `rol_cat_id` int(10) UNSIGNED NOT NULL,
  `rol_lst_id` int(10) UNSIGNED DEFAULT NULL,
  `rol_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `rol_description` varchar(4000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rol_assign_roles` tinyint(1) NOT NULL DEFAULT '0',
  `rol_approve_users` tinyint(1) NOT NULL DEFAULT '0',
  `rol_announcements` tinyint(1) NOT NULL DEFAULT '0',
  `rol_dates` tinyint(1) NOT NULL DEFAULT '0',
  `rol_download` tinyint(1) NOT NULL DEFAULT '0',
  `rol_edit_user` tinyint(1) NOT NULL DEFAULT '0',
  `rol_guestbook` tinyint(1) NOT NULL DEFAULT '0',
  `rol_guestbook_comments` tinyint(1) NOT NULL DEFAULT '0',
  `rol_inventory` tinyint(1) NOT NULL DEFAULT '0',
  `rol_mail_to_all` tinyint(1) NOT NULL DEFAULT '0',
  `rol_mail_this_role` smallint(6) NOT NULL DEFAULT '0',
  `rol_photo` tinyint(1) NOT NULL DEFAULT '0',
  `rol_profile` tinyint(1) NOT NULL DEFAULT '0',
  `rol_weblinks` tinyint(1) NOT NULL DEFAULT '0',
  `rol_this_list_view` smallint(6) NOT NULL DEFAULT '0',
  `rol_all_lists_view` tinyint(1) NOT NULL DEFAULT '0',
  `rol_default_registration` tinyint(1) NOT NULL DEFAULT '0',
  `rol_leader_rights` smallint(6) NOT NULL DEFAULT '0',
  `rol_start_date` date DEFAULT NULL,
  `rol_start_time` time DEFAULT NULL,
  `rol_end_date` date DEFAULT NULL,
  `rol_end_time` time DEFAULT NULL,
  `rol_weekday` smallint(6) DEFAULT NULL,
  `rol_location` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rol_max_members` int(11) DEFAULT NULL,
  `rol_cost` float UNSIGNED DEFAULT NULL,
  `rol_cost_period` smallint(6) DEFAULT NULL,
  `rol_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `rol_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rol_usr_id_change` int(10) UNSIGNED DEFAULT NULL,
  `rol_timestamp_change` timestamp NULL DEFAULT NULL,
  `rol_valid` tinyint(1) NOT NULL DEFAULT '1',
  `rol_system` tinyint(1) NOT NULL DEFAULT '0',
  `rol_visible` tinyint(1) NOT NULL DEFAULT '1',
  `rol_administrator` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_roles`
--

INSERT INTO `adm_roles` (`rol_id`, `rol_cat_id`, `rol_lst_id`, `rol_name`, `rol_description`, `rol_assign_roles`, `rol_approve_users`, `rol_announcements`, `rol_dates`, `rol_download`, `rol_edit_user`, `rol_guestbook`, `rol_guestbook_comments`, `rol_inventory`, `rol_mail_to_all`, `rol_mail_this_role`, `rol_photo`, `rol_profile`, `rol_weblinks`, `rol_this_list_view`, `rol_all_lists_view`, `rol_default_registration`, `rol_leader_rights`, `rol_start_date`, `rol_start_time`, `rol_end_date`, `rol_end_time`, `rol_weekday`, `rol_location`, `rol_max_members`, `rol_cost`, `rol_cost_period`, `rol_usr_id_create`, `rol_timestamp_create`, `rol_usr_id_change`, `rol_timestamp_change`, `rol_valid`, `rol_system`, `rol_visible`, `rol_administrator`) VALUES
(1, 6, NULL, 'Administrator', 'Group of system administrators', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2017-08-06 19:24:16', NULL, NULL, 1, 0, 1, 1),
(2, 6, NULL, 'Member', 'All organization members', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1, 0, 1, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2017-08-06 19:24:16', NULL, NULL, 1, 0, 1, 0),
(3, 6, NULL, 'Association&rsquo;s board', 'Administrative board of association', 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 2, 0, 1, 1, 1, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2017-08-06 19:24:16', NULL, NULL, 1, 0, 1, 0),
(4, 3, NULL, 'Event 2017-08-07 00:00 - 1', 'Test1', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, 5, NULL, NULL, 2, '2017-08-06 19:25:31', NULL, NULL, 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `adm_roles_rights`
--

CREATE TABLE `adm_roles_rights` (
  `ror_id` int(10) UNSIGNED NOT NULL,
  `ror_name_intern` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ror_table` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_roles_rights`
--

INSERT INTO `adm_roles_rights` (`ror_id`, `ror_name_intern`, `ror_table`) VALUES
(1, 'folder_view', 'adm_folders'),
(2, 'folder_upload', 'adm_folders');

-- --------------------------------------------------------

--
-- Table structure for table `adm_roles_rights_data`
--

CREATE TABLE `adm_roles_rights_data` (
  `rrd_id` int(10) UNSIGNED NOT NULL,
  `rrd_ror_id` int(10) UNSIGNED NOT NULL,
  `rrd_rol_id` int(10) UNSIGNED NOT NULL,
  `rrd_object_id` int(10) UNSIGNED NOT NULL,
  `rrd_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `rrd_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adm_role_dependencies`
--

CREATE TABLE `adm_role_dependencies` (
  `rld_rol_id_parent` int(10) UNSIGNED NOT NULL,
  `rld_rol_id_child` int(10) UNSIGNED NOT NULL,
  `rld_comment` text COLLATE utf8_unicode_ci,
  `rld_usr_id` int(10) UNSIGNED DEFAULT NULL,
  `rld_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adm_rooms`
--

CREATE TABLE `adm_rooms` (
  `room_id` int(10) UNSIGNED NOT NULL,
  `room_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `room_description` text COLLATE utf8_unicode_ci,
  `room_capacity` int(11) NOT NULL,
  `room_overhang` int(11) DEFAULT NULL,
  `room_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `room_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `room_usr_id_change` int(10) UNSIGNED DEFAULT NULL,
  `room_timestamp_change` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_rooms`
--

INSERT INTO `adm_rooms` (`room_id`, `room_name`, `room_description`, `room_capacity`, `room_overhang`, `room_usr_id_create`, `room_timestamp_create`, `room_usr_id_change`, `room_timestamp_change`) VALUES
(1, 'Conference room', 'Meetings can take place here. Room has to be reserved before. Beamer is free for use.', 15, NULL, 1, '2017-08-06 19:24:16', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `adm_sessions`
--

CREATE TABLE `adm_sessions` (
  `ses_id` int(10) UNSIGNED NOT NULL,
  `ses_usr_id` int(10) UNSIGNED DEFAULT NULL,
  `ses_org_id` int(10) UNSIGNED NOT NULL,
  `ses_session_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ses_begin` timestamp NULL DEFAULT NULL,
  `ses_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ses_ip_address` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `ses_binary` blob,
  `ses_renew` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_sessions`
--

INSERT INTO `adm_sessions` (`ses_id`, `ses_usr_id`, `ses_org_id`, `ses_session_id`, `ses_begin`, `ses_timestamp`, `ses_ip_address`, `ses_binary`, `ses_renew`) VALUES
(1, NULL, 1, '09ae7cad71f7ed5211fcf493aaf341ac', '2017-08-06 19:24:28', '2017-08-07 00:24:19', '::1', NULL, 0),
(2, 2, 1, 'b949ee52176437458a470aa0d55438e6', '2017-08-06 20:21:57', '2017-08-06 20:23:26', '::1', NULL, 1),
(3, NULL, 1, '5b78cb1646b4d5826d03ab7058739a44', '2017-08-06 20:23:36', '2017-08-06 23:59:13', '::1', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `adm_texts`
--

CREATE TABLE `adm_texts` (
  `txt_id` int(10) UNSIGNED NOT NULL,
  `txt_org_id` int(10) UNSIGNED NOT NULL,
  `txt_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `txt_text` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_texts`
--

INSERT INTO `adm_texts` (`txt_id`, `txt_org_id`, `txt_name`, `txt_text`) VALUES
(1, 1, 'SYSMAIL_REGISTRATION_USER', '#subject# Registration on #organization_long_name# website approved\r\n#content# Hello #user_first_name#,\r\n\r\nyour registration on #organization_homepage# is approved.\r\n\r\nNow you may log in with your username: #user_login_name#\r\nand your password.\r\n\r\nIn case of any questions, please don&rsquo;t hesitate to contact the administrator via email to #administrator_email# .\r\n\r\nCheers,\r\nThe administrators'),
(2, 1, 'SYSMAIL_REGISTRATION_WEBMASTER', '#subject# New registration at #organization_long_name# website\r\n#content# A new user registered himself on #organization_homepage#.\r\n\r\nSurname: #user_last_name#\r\nFirst Name: #user_first_name#\r\nE-Mail: #user_email#\r\n\r\n\r\nThis message was generated automatically.'),
(3, 1, 'SYSMAIL_REFUSE_REGISTRATION', '#subject# in registration at #organization_long_name# rejected.\r\n#content#Hello #user_first_name# your application at #organization_homepage# was rejected.\r\n\r\nRegistrations are accepted in general by our users. If you are a member and your registration was still rejected, it may be because you were not identified as member.\r\nTo clarify the reasons for the rejection please contact the administrator #administrator_email# from #organization_homepage#.\r\n\r\nRegards,\r\nThe administrators'),
(4, 1, 'SYSMAIL_NEW_PASSWORD', '#subject# Login details for #organization_homepage#\r\n#content# Hello #user_first_name#,\r\n\r\nyour new login details for the #organization_long_name# website:\r\nUsername: #user_login_name#\r\nPassword: #variable1#\r\n\r\nThe password was generated automatically,\r\ntherefore you should log in at #organization_homepage# to change it under \"My profile\".\r\n\r\nCheers,\r\nThe administrators'),
(5, 1, 'SYSMAIL_ACTIVATION_LINK', '#subject# Your requested password for #organization_short_name# website\r\n#content# Hello #user_first_name#,\r\n\r\nyou requested a new password!\r\n\r\nYour log in details are:\r\nUsername: #user_login_name#\r\nPassword: #variable1#\r\n\r\nTo activate your password, please follow this link:\r\n\r\n#variable2#\r\n\r\nThe password was generated automatically,\r\ntherefore you should log in at #organization_homepage# to change it under \"My profile\".\r\n\r\nGreetings,\r\nThe administrators');

-- --------------------------------------------------------

--
-- Table structure for table `adm_users`
--

CREATE TABLE `adm_users` (
  `usr_id` int(10) UNSIGNED NOT NULL,
  `usr_login_name` varchar(35) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usr_password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usr_new_password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usr_photo` blob,
  `usr_text` text COLLATE utf8_unicode_ci,
  `usr_activation_code` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usr_last_login` timestamp NULL DEFAULT NULL,
  `usr_actual_login` timestamp NULL DEFAULT NULL,
  `usr_number_login` int(11) NOT NULL DEFAULT '0',
  `usr_date_invalid` timestamp NULL DEFAULT NULL,
  `usr_number_invalid` smallint(6) NOT NULL DEFAULT '0',
  `usr_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `usr_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usr_usr_id_change` int(10) UNSIGNED DEFAULT NULL,
  `usr_timestamp_change` timestamp NULL DEFAULT NULL,
  `usr_valid` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_users`
--

INSERT INTO `adm_users` (`usr_id`, `usr_login_name`, `usr_password`, `usr_new_password`, `usr_photo`, `usr_text`, `usr_activation_code`, `usr_last_login`, `usr_actual_login`, `usr_number_login`, `usr_date_invalid`, `usr_number_invalid`, `usr_usr_id_create`, `usr_timestamp_create`, `usr_usr_id_change`, `usr_timestamp_change`, `usr_valid`) VALUES
(1, 'System', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, '2017-08-06 19:24:16', NULL, NULL, 0),
(2, 'rajkotraja', '$2y$10$mOpODmJdRGMhtCmKvHOxduqCELmfev8.4NwkRjh2D150GAmpNgEoa', NULL, NULL, NULL, NULL, '2017-08-06 20:23:45', '2017-08-07 00:20:44', 9, NULL, 0, 1, '2017-08-06 19:24:16', NULL, NULL, 1),
(3, 'user1', '$2y$11$VvfGttjbYVMCIPHehsl7fuhIgvza6bRKXEwBsTeFvxqSxY3WpGM1S', NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-06 19:35:30', 3, 3, '2017-08-06 19:26:48', 2, '2017-08-06 19:33:56', 1),
(5, 'user3', '$2y$11$xf7/W/9laS7oZnKvK3yy7enzEytbwqFMr8K2LuVda6NfPJMJPT0qO', NULL, NULL, NULL, NULL, '2017-08-06 19:42:56', '2017-08-06 19:47:58', 2, NULL, 0, 5, '2017-08-06 19:40:16', 2, '2017-08-06 19:40:54', 1);

-- --------------------------------------------------------

--
-- Table structure for table `adm_user_data`
--

CREATE TABLE `adm_user_data` (
  `usd_id` int(10) UNSIGNED NOT NULL,
  `usd_usr_id` int(10) UNSIGNED NOT NULL,
  `usd_usf_id` int(10) UNSIGNED NOT NULL,
  `usd_value` varchar(4000) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_user_data`
--

INSERT INTO `adm_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES
(1, 2, 1, 'Raja'),
(2, 2, 2, 'sid'),
(3, 2, 12, 'rajkotraja99@gmail.com'),
(4, 1, 1, 'System'),
(5, 3, 1, 'user1'),
(6, 3, 2, 'user1'),
(7, 3, 12, 'abcd99523@yahoo.com'),
(11, 5, 1, 'user3'),
(12, 5, 2, 'user3'),
(13, 5, 12, 'siddharth@oraculous.in');

-- --------------------------------------------------------

--
-- Table structure for table `adm_user_fields`
--

CREATE TABLE `adm_user_fields` (
  `usf_id` int(10) UNSIGNED NOT NULL,
  `usf_cat_id` int(10) UNSIGNED NOT NULL,
  `usf_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `usf_name_intern` varchar(110) COLLATE utf8_unicode_ci NOT NULL,
  `usf_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `usf_description` text COLLATE utf8_unicode_ci,
  `usf_value_list` text COLLATE utf8_unicode_ci,
  `usf_icon` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usf_url` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usf_system` tinyint(1) NOT NULL DEFAULT '0',
  `usf_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `usf_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `usf_mandatory` tinyint(1) NOT NULL DEFAULT '0',
  `usf_sequence` smallint(6) NOT NULL,
  `usf_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `usf_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usf_usr_id_change` int(10) UNSIGNED DEFAULT NULL,
  `usf_timestamp_change` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_user_fields`
--

INSERT INTO `adm_user_fields` (`usf_id`, `usf_cat_id`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_value_list`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_mandatory`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES
(1, 1, 'TEXT', 'LAST_NAME', 'SYS_LASTNAME', NULL, NULL, NULL, NULL, 1, 1, 0, 1, 1, 1, '2017-08-06 19:24:16', NULL, NULL),
(2, 1, 'TEXT', 'FIRST_NAME', 'SYS_FIRSTNAME', NULL, NULL, NULL, NULL, 1, 1, 0, 1, 2, 1, '2017-08-06 19:24:16', NULL, NULL),
(3, 1, 'TEXT', 'ADDRESS', 'SYS_ADDRESS', NULL, NULL, NULL, NULL, 0, 0, 0, 0, 3, 1, '2017-08-06 19:24:16', NULL, NULL),
(4, 1, 'TEXT', 'POSTCODE', 'SYS_POSTCODE', NULL, NULL, NULL, NULL, 0, 0, 0, 0, 4, 1, '2017-08-06 19:24:16', NULL, NULL),
(5, 1, 'TEXT', 'CITY', 'SYS_CITY', NULL, NULL, NULL, NULL, 0, 0, 0, 0, 5, 1, '2017-08-06 19:24:16', NULL, NULL),
(6, 1, 'TEXT', 'COUNTRY', 'SYS_COUNTRY', NULL, NULL, NULL, NULL, 0, 0, 0, 0, 6, 1, '2017-08-06 19:24:16', NULL, NULL),
(7, 1, 'PHONE', 'PHONE', 'SYS_PHONE', NULL, NULL, NULL, NULL, 0, 0, 0, 0, 7, 1, '2017-08-06 19:24:16', NULL, NULL),
(8, 1, 'PHONE', 'MOBILE', 'SYS_MOBILE', NULL, NULL, NULL, NULL, 0, 0, 0, 0, 8, 1, '2017-08-06 19:24:16', NULL, NULL),
(9, 1, 'PHONE', 'FAX', 'SYS_FAX', NULL, NULL, NULL, NULL, 0, 0, 0, 0, 9, 1, '2017-08-06 19:24:16', NULL, NULL),
(10, 1, 'DATE', 'BIRTHDAY', 'SYS_BIRTHDAY', NULL, NULL, NULL, NULL, 0, 0, 0, 0, 10, 1, '2017-08-06 19:24:16', NULL, NULL),
(11, 1, 'RADIO_BUTTON', 'GENDER', 'SYS_GENDER', NULL, 'male.png|SYS_MALE\nfemale.png|SYS_FEMALE', NULL, NULL, 0, 0, 0, 0, 11, 1, '2017-08-06 19:24:16', NULL, NULL),
(12, 1, 'EMAIL', 'EMAIL', 'SYS_EMAIL', NULL, NULL, NULL, NULL, 1, 0, 0, 1, 12, 1, '2017-08-06 19:24:16', NULL, NULL),
(13, 1, 'URL', 'WEBSITE', 'SYS_WEBSITE', NULL, NULL, NULL, NULL, 0, 0, 0, 0, 13, 1, '2017-08-06 19:24:16', NULL, NULL),
(14, 2, 'TEXT', 'AOL_INSTANT_MESSENGER', 'INS_AOL_INSTANT_MESSENGER', NULL, NULL, 'aim.png', NULL, 0, 0, 0, 0, 1, 1, '2017-08-06 19:24:16', NULL, NULL),
(15, 2, 'TEXT', 'FACEBOOK', 'INS_FACEBOOK', 'Would you like to set a link to your Facebook profile? Your Facebook login name is required. Log in to your Facebook account and display your profile. Copy URL in this field and save your profile here. Visitors of your profile are now able to open your Facebook profile directly.', NULL, 'facebook.png', 'https://www.facebook.com/#user_content#', 0, 0, 0, 0, 2, 1, '2017-08-06 19:24:16', NULL, NULL),
(16, 2, 'TEXT', 'GOOGLE_PLUS', 'INS_GOOGLE_PLUS', 'Would you like to set a link to your Google+ profile? In order to do this, you will need your profile Google+ profile number. Log in to your Google+ account and display your profile. Copy URL in this field and save your profile here. Visitors of your profile are now able to open your Google+ profile directly.', NULL, 'google_plus.png', 'https://plus.google.com/#user_content#/posts', 0, 0, 0, 0, 3, 1, '2017-08-06 19:24:16', NULL, NULL),
(17, 2, 'TEXT', 'ICQ', 'INS_ICQ', 'Enter your ICQ number here. If your status can be shown on the web (enabled in Skype), it will be displayed in your profile.', NULL, 'icq.png', 'https://www.icq.com/people/#user_content#', 0, 0, 0, 0, 4, 1, '2017-08-06 19:24:16', NULL, NULL),
(18, 2, 'TEXT', 'SKYPE', 'INS_SKYPE', 'Enter your exact Skype name here. If your status can be shown on the web (enabled in ICQ), it will be displayed in your profile.', NULL, 'skype.png', NULL, 0, 0, 0, 0, 5, 1, '2017-08-06 19:24:16', NULL, NULL),
(19, 2, 'TEXT', 'TWITTER', 'INS_TWITTER', 'Would you like to set a link to your Twitter profile? Your Twitter login name is required. Log in to your Twitter account and display your profile. Copy URL in this field and save your profile here. Visitors of your profile are now able to open your Twitter profile directly.', NULL, 'twitter.png', 'https://twitter.com/#user_content#', 0, 0, 0, 0, 6, 1, '2017-08-06 19:24:16', NULL, NULL),
(20, 2, 'TEXT', 'XING', 'INS_XING', 'Would you like to set a link to your Xing profile? Your Xing login name is required. Log in to your Xing account and display your profile. Copy URL in this field and save your profile here. Visitors of your profile are now able to open your Xing profile directly.', NULL, 'xing.png', 'https://www.xing.com/profile/#user_content#', 0, 0, 0, 0, 7, 1, '2017-08-06 19:24:16', NULL, NULL),
(21, 2, 'TEXT', 'YAHOO_MESSENGER', 'INS_YAHOO_MESSENGER', NULL, NULL, 'yahoo.png', NULL, 0, 0, 0, 0, 8, 1, '2017-08-06 19:24:16', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `adm_user_log`
--

CREATE TABLE `adm_user_log` (
  `usl_id` int(11) NOT NULL,
  `usl_usr_id` int(10) UNSIGNED NOT NULL,
  `usl_usf_id` int(10) UNSIGNED NOT NULL,
  `usl_value_old` varchar(4000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usl_value_new` varchar(4000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usl_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `usl_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usl_comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adm_user_relations`
--

CREATE TABLE `adm_user_relations` (
  `ure_id` int(10) UNSIGNED NOT NULL,
  `ure_urt_id` int(10) UNSIGNED NOT NULL,
  `ure_usr_id1` int(10) UNSIGNED NOT NULL,
  `ure_usr_id2` int(10) UNSIGNED NOT NULL,
  `ure_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `ure_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ure_usr_id_change` int(10) UNSIGNED DEFAULT NULL,
  `ure_timestamp_change` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `adm_user_relation_types`
--

CREATE TABLE `adm_user_relation_types` (
  `urt_id` int(10) UNSIGNED NOT NULL,
  `urt_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `urt_name_male` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `urt_name_female` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `urt_id_inverse` int(10) UNSIGNED DEFAULT NULL,
  `urt_usr_id_create` int(10) UNSIGNED DEFAULT NULL,
  `urt_timestamp_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `urt_usr_id_change` int(10) UNSIGNED DEFAULT NULL,
  `urt_timestamp_change` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `adm_user_relation_types`
--

INSERT INTO `adm_user_relation_types` (`urt_id`, `urt_name`, `urt_name_male`, `urt_name_female`, `urt_id_inverse`, `urt_usr_id_create`, `urt_timestamp_create`, `urt_usr_id_change`, `urt_timestamp_change`) VALUES
(1, 'Parent', 'Father', 'Mother', 2, 1, '2017-08-06 19:24:16', NULL, NULL),
(2, 'Child', 'Son', 'Daughter', 1, 1, '2017-08-06 19:24:16', NULL, NULL),
(3, 'Sibling', 'Brother', 'Sister', 3, 1, '2017-08-06 19:24:16', NULL, NULL),
(4, 'Spouse', 'Husband', 'Wife', 4, 1, '2017-08-06 19:24:16', NULL, NULL),
(5, 'Partner', 'Partner', 'Partner', 5, 1, '2017-08-06 19:24:16', NULL, NULL),
(6, 'Friend', 'Friend', 'Girlfriend', 6, 1, '2017-08-06 19:24:16', NULL, NULL),
(7, 'Superior', 'Male superior', 'Female superior', 8, 1, '2017-08-06 19:24:16', NULL, NULL),
(8, 'Subordinate', 'Male subordinate', 'Female subordinate', 7, 1, '2017-08-06 19:24:16', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `api_access`
--

CREATE TABLE `api_access` (
  `id` int(11) UNSIGNED NOT NULL,
  `key` varchar(40) NOT NULL DEFAULT '',
  `controller` varchar(50) NOT NULL DEFAULT '',
  `date_created` datetime DEFAULT NULL,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `api_keys`
--

CREATE TABLE `api_keys` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `key` varchar(40) NOT NULL,
  `level` int(2) NOT NULL,
  `ignore_limits` tinyint(1) NOT NULL DEFAULT '0',
  `is_private_key` tinyint(1) NOT NULL DEFAULT '0',
  `ip_addresses` text,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `api_keys`
--

INSERT INTO `api_keys` (`id`, `user_id`, `key`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`) VALUES
(1, 0, 'anonymous', 1, 1, 0, NULL, 1463388382);

-- --------------------------------------------------------

--
-- Table structure for table `api_limits`
--

CREATE TABLE `api_limits` (
  `id` int(11) NOT NULL,
  `uri` varchar(255) NOT NULL,
  `count` int(10) NOT NULL,
  `hour_started` int(11) NOT NULL,
  `api_key` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `api_logs`
--

CREATE TABLE `api_logs` (
  `id` int(11) NOT NULL,
  `uri` varchar(255) NOT NULL,
  `method` varchar(6) NOT NULL,
  `params` text,
  `api_key` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `time` int(11) NOT NULL,
  `rtime` float DEFAULT NULL,
  `authorized` varchar(1) NOT NULL,
  `response_code` smallint(3) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'members', 'General User');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1, '127.0.0.1', 'member', '$2y$08$kkqUE2hrqAJtg.pPnAhvL.1iE7LIujK5LZ61arONLpaBBWh/ek61G', NULL, 'member@member.com', NULL, NULL, NULL, NULL, 1451903855, 1451905011, 1, 'Member', 'One', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_groups`
--
ALTER TABLE `admin_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_login_attempts`
--
ALTER TABLE `admin_login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_users_groups`
--
ALTER TABLE `admin_users_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adm_announcements`
--
ALTER TABLE `adm_announcements`
  ADD PRIMARY KEY (`ann_id`),
  ADD KEY `adm_FK_ANN_USR_CHANGE` (`ann_usr_id_change`);

--
-- Indexes for table `adm_auto_login`
--
ALTER TABLE `adm_auto_login`
  ADD PRIMARY KEY (`atl_id`),
  ADD KEY `adm_FK_ATL_USR` (`atl_usr_id`),
  ADD KEY `adm_FK_ATL_ORG` (`atl_org_id`);

--
-- Indexes for table `adm_categories`
--
ALTER TABLE `adm_categories`
  ADD PRIMARY KEY (`cat_id`),
  ADD KEY `adm_FK_CAT_ORG` (`cat_org_id`),
  ADD KEY `adm_FK_CAT_USR_CREATE` (`cat_usr_id_create`),
  ADD KEY `adm_FK_CAT_USR_CHANGE` (`cat_usr_id_change`);

--
-- Indexes for table `adm_components`
--
ALTER TABLE `adm_components`
  ADD PRIMARY KEY (`com_id`);

--
-- Indexes for table `adm_dates`
--
ALTER TABLE `adm_dates`
  ADD PRIMARY KEY (`dat_id`),
  ADD KEY `adm_FK_DAT_CAT` (`dat_cat_id`),
  ADD KEY `adm_FK_DAT_ROL` (`dat_rol_id`),
  ADD KEY `adm_FK_DAT_ROOM` (`dat_room_id`),
  ADD KEY `adm_FK_DAT_USR_CREATE` (`dat_usr_id_create`),
  ADD KEY `adm_FK_DAT_USR_CHANGE` (`dat_usr_id_change`);

--
-- Indexes for table `adm_date_role`
--
ALTER TABLE `adm_date_role`
  ADD PRIMARY KEY (`dtr_id`),
  ADD KEY `adm_FK_DTR_DAT` (`dtr_dat_id`),
  ADD KEY `adm_FK_DTR_ROL` (`dtr_rol_id`);

--
-- Indexes for table `adm_files`
--
ALTER TABLE `adm_files`
  ADD PRIMARY KEY (`fil_id`),
  ADD KEY `adm_FK_FIL_FOL` (`fil_fol_id`),
  ADD KEY `adm_FK_FIL_USR` (`fil_usr_id`);

--
-- Indexes for table `adm_folders`
--
ALTER TABLE `adm_folders`
  ADD PRIMARY KEY (`fol_id`),
  ADD KEY `adm_FK_FOL_ORG` (`fol_org_id`),
  ADD KEY `adm_FK_FOL_FOL_PARENT` (`fol_fol_id_parent`),
  ADD KEY `adm_FK_FOL_USR` (`fol_usr_id`);

--
-- Indexes for table `adm_guestbook`
--
ALTER TABLE `adm_guestbook`
  ADD PRIMARY KEY (`gbo_id`),
  ADD KEY `adm_FK_GBO_ORG` (`gbo_org_id`),
  ADD KEY `adm_FK_GBO_USR_CREATE` (`gbo_usr_id_create`),
  ADD KEY `adm_FK_GBO_USR_CHANGE` (`gbo_usr_id_change`);

--
-- Indexes for table `adm_guestbook_comments`
--
ALTER TABLE `adm_guestbook_comments`
  ADD PRIMARY KEY (`gbc_id`),
  ADD KEY `adm_FK_GBC_GBO` (`gbc_gbo_id`),
  ADD KEY `adm_FK_GBC_USR_CREATE` (`gbc_usr_id_create`),
  ADD KEY `adm_FK_GBC_USR_CHANGE` (`gbc_usr_id_change`);

--
-- Indexes for table `adm_ids`
--
ALTER TABLE `adm_ids`
  ADD KEY `adm_FK_IDS_USR_ID` (`ids_usr_id`);

--
-- Indexes for table `adm_invent`
--
ALTER TABLE `adm_invent`
  ADD PRIMARY KEY (`inv_id`);

--
-- Indexes for table `adm_invent_data`
--
ALTER TABLE `adm_invent_data`
  ADD PRIMARY KEY (`ind_id`),
  ADD UNIQUE KEY `IDX_adm_IND_ITM_INF_ID` (`ind_itm_id`,`ind_inf_id`);

--
-- Indexes for table `adm_invent_fields`
--
ALTER TABLE `adm_invent_fields`
  ADD PRIMARY KEY (`inf_id`),
  ADD UNIQUE KEY `IDX_adm_INF_NAME_INTERN` (`inf_name_intern`);

--
-- Indexes for table `adm_links`
--
ALTER TABLE `adm_links`
  ADD PRIMARY KEY (`lnk_id`),
  ADD KEY `adm_FK_LNK_CAT` (`lnk_cat_id`),
  ADD KEY `adm_FK_LNK_USR_CREATE` (`lnk_usr_id_create`),
  ADD KEY `adm_FK_LNK_USR_CHANGE` (`lnk_usr_id_change`);

--
-- Indexes for table `adm_lists`
--
ALTER TABLE `adm_lists`
  ADD PRIMARY KEY (`lst_id`),
  ADD KEY `adm_FK_LST_USR` (`lst_usr_id`),
  ADD KEY `adm_FK_LST_ORG` (`lst_org_id`);

--
-- Indexes for table `adm_list_columns`
--
ALTER TABLE `adm_list_columns`
  ADD PRIMARY KEY (`lsc_id`),
  ADD KEY `adm_FK_LSC_LST` (`lsc_lst_id`),
  ADD KEY `adm_FK_LSC_USF` (`lsc_usf_id`);

--
-- Indexes for table `adm_members`
--
ALTER TABLE `adm_members`
  ADD PRIMARY KEY (`mem_id`),
  ADD KEY `IDX_adm_MEM_ROL_USR_ID` (`mem_rol_id`,`mem_usr_id`),
  ADD KEY `adm_FK_MEM_USR` (`mem_usr_id`),
  ADD KEY `adm_FK_MEM_USR_CREATE` (`mem_usr_id_create`),
  ADD KEY `adm_FK_MEM_USR_CHANGE` (`mem_usr_id_change`);

--
-- Indexes for table `adm_messages`
--
ALTER TABLE `adm_messages`
  ADD PRIMARY KEY (`msg_id`),
  ADD KEY `adm_FK_MSG_USR_SENDER` (`msg_usr_id_sender`);

--
-- Indexes for table `adm_messages_content`
--
ALTER TABLE `adm_messages_content`
  ADD PRIMARY KEY (`msc_id`),
  ADD KEY `IDX_adm_MSC_PART_ID` (`msc_part_id`),
  ADD KEY `adm_FK_MSC_MSG_ID` (`msc_msg_id`),
  ADD KEY `adm_FK_MSC_USR_ID` (`msc_usr_id`);

--
-- Indexes for table `adm_organizations`
--
ALTER TABLE `adm_organizations`
  ADD PRIMARY KEY (`org_id`),
  ADD UNIQUE KEY `ak_adm_shortname` (`org_shortname`),
  ADD KEY `adm_FK_ORG_ORG_PARENT` (`org_org_id_parent`);

--
-- Indexes for table `adm_photos`
--
ALTER TABLE `adm_photos`
  ADD PRIMARY KEY (`pho_id`),
  ADD KEY `adm_FK_PHO_PHO_PARENT` (`pho_pho_id_parent`),
  ADD KEY `adm_FK_PHO_ORG` (`pho_org_id`),
  ADD KEY `adm_FK_PHO_USR_CREATE` (`pho_usr_id_create`),
  ADD KEY `adm_FK_PHO_USR_CHANGE` (`pho_usr_id_change`);

--
-- Indexes for table `adm_preferences`
--
ALTER TABLE `adm_preferences`
  ADD PRIMARY KEY (`prf_id`),
  ADD UNIQUE KEY `IDX_adm_PRF_ORG_ID_NAME` (`prf_org_id`,`prf_name`);

--
-- Indexes for table `adm_registrations`
--
ALTER TABLE `adm_registrations`
  ADD PRIMARY KEY (`reg_id`),
  ADD KEY `adm_FK_REG_ORG` (`reg_org_id`),
  ADD KEY `adm_FK_REG_USR` (`reg_usr_id`);

--
-- Indexes for table `adm_roles`
--
ALTER TABLE `adm_roles`
  ADD PRIMARY KEY (`rol_id`),
  ADD KEY `adm_FK_ROL_CAT` (`rol_cat_id`),
  ADD KEY `adm_FK_ROL_LST_ID` (`rol_lst_id`),
  ADD KEY `adm_FK_ROL_USR_CREATE` (`rol_usr_id_create`),
  ADD KEY `adm_FK_ROL_USR_CHANGE` (`rol_usr_id_change`);

--
-- Indexes for table `adm_roles_rights`
--
ALTER TABLE `adm_roles_rights`
  ADD PRIMARY KEY (`ror_id`);

--
-- Indexes for table `adm_roles_rights_data`
--
ALTER TABLE `adm_roles_rights_data`
  ADD PRIMARY KEY (`rrd_id`),
  ADD UNIQUE KEY `IDX_adm_RRD_ROR_ROL_OBJECT_ID` (`rrd_ror_id`,`rrd_rol_id`,`rrd_object_id`),
  ADD KEY `adm_FK_RRD_ROL` (`rrd_rol_id`),
  ADD KEY `adm_FK_RRD_USR_CREATE` (`rrd_usr_id_create`);

--
-- Indexes for table `adm_role_dependencies`
--
ALTER TABLE `adm_role_dependencies`
  ADD PRIMARY KEY (`rld_rol_id_parent`,`rld_rol_id_child`),
  ADD KEY `adm_FK_RLD_ROL_CHILD` (`rld_rol_id_child`),
  ADD KEY `adm_FK_RLD_USR` (`rld_usr_id`);

--
-- Indexes for table `adm_rooms`
--
ALTER TABLE `adm_rooms`
  ADD PRIMARY KEY (`room_id`),
  ADD KEY `adm_FK_ROOM_USR_CREATE` (`room_usr_id_create`),
  ADD KEY `adm_FK_ROOM_USR_CHANGE` (`room_usr_id_change`);

--
-- Indexes for table `adm_sessions`
--
ALTER TABLE `adm_sessions`
  ADD PRIMARY KEY (`ses_id`),
  ADD KEY `IDX_adm_SESSION_ID` (`ses_session_id`),
  ADD KEY `adm_FK_SES_ORG` (`ses_org_id`),
  ADD KEY `adm_FK_SES_USR` (`ses_usr_id`);

--
-- Indexes for table `adm_texts`
--
ALTER TABLE `adm_texts`
  ADD PRIMARY KEY (`txt_id`),
  ADD KEY `adm_FK_TXT_ORG` (`txt_org_id`);

--
-- Indexes for table `adm_users`
--
ALTER TABLE `adm_users`
  ADD PRIMARY KEY (`usr_id`),
  ADD UNIQUE KEY `IDX_adm_USR_LOGIN_NAME` (`usr_login_name`),
  ADD KEY `adm_FK_USR_USR_CREATE` (`usr_usr_id_create`),
  ADD KEY `adm_FK_USR_USR_CHANGE` (`usr_usr_id_change`);

--
-- Indexes for table `adm_user_data`
--
ALTER TABLE `adm_user_data`
  ADD PRIMARY KEY (`usd_id`),
  ADD UNIQUE KEY `IDX_adm_USD_USR_USF_ID` (`usd_usr_id`,`usd_usf_id`),
  ADD KEY `adm_FK_USD_USF` (`usd_usf_id`);

--
-- Indexes for table `adm_user_fields`
--
ALTER TABLE `adm_user_fields`
  ADD PRIMARY KEY (`usf_id`),
  ADD UNIQUE KEY `IDX_adm_USF_NAME_INTERN` (`usf_name_intern`),
  ADD KEY `adm_FK_USF_CAT` (`usf_cat_id`),
  ADD KEY `adm_FK_USF_USR_CREATE` (`usf_usr_id_create`),
  ADD KEY `adm_FK_USF_USR_CHANGE` (`usf_usr_id_change`);

--
-- Indexes for table `adm_user_log`
--
ALTER TABLE `adm_user_log`
  ADD PRIMARY KEY (`usl_id`),
  ADD KEY `adm_FK_USER_LOG_1` (`usl_usr_id`),
  ADD KEY `adm_FK_USER_LOG_2` (`usl_usr_id_create`),
  ADD KEY `adm_FK_USER_LOG_3` (`usl_usf_id`);

--
-- Indexes for table `adm_user_relations`
--
ALTER TABLE `adm_user_relations`
  ADD PRIMARY KEY (`ure_id`),
  ADD UNIQUE KEY `adm_IDX_URE_URT_USR` (`ure_urt_id`,`ure_usr_id1`,`ure_usr_id2`),
  ADD KEY `adm_FK_URE_USR1` (`ure_usr_id1`),
  ADD KEY `adm_FK_URE_USR2` (`ure_usr_id2`),
  ADD KEY `adm_FK_URE_USR_CHANGE` (`ure_usr_id_change`),
  ADD KEY `adm_FK_URE_USR_CREATE` (`ure_usr_id_create`);

--
-- Indexes for table `adm_user_relation_types`
--
ALTER TABLE `adm_user_relation_types`
  ADD PRIMARY KEY (`urt_id`),
  ADD UNIQUE KEY `adm_IDX_URE_URT_NAME` (`urt_name`),
  ADD KEY `adm_FK_URT_ID_INVERSE` (`urt_id_inverse`),
  ADD KEY `adm_FK_URT_USR_CHANGE` (`urt_usr_id_change`),
  ADD KEY `adm_FK_URT_USR_CREATE` (`urt_usr_id_create`);

--
-- Indexes for table `api_access`
--
ALTER TABLE `api_access`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `api_keys`
--
ALTER TABLE `api_keys`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `api_limits`
--
ALTER TABLE `api_limits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `api_logs`
--
ALTER TABLE `api_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_groups`
--
ALTER TABLE `admin_groups`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `admin_login_attempts`
--
ALTER TABLE `admin_login_attempts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `admin_users_groups`
--
ALTER TABLE `admin_users_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `adm_announcements`
--
ALTER TABLE `adm_announcements`
  MODIFY `ann_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adm_auto_login`
--
ALTER TABLE `adm_auto_login`
  MODIFY `atl_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adm_categories`
--
ALTER TABLE `adm_categories`
  MODIFY `cat_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `adm_components`
--
ALTER TABLE `adm_components`
  MODIFY `com_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `adm_dates`
--
ALTER TABLE `adm_dates`
  MODIFY `dat_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `adm_date_role`
--
ALTER TABLE `adm_date_role`
  MODIFY `dtr_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `adm_files`
--
ALTER TABLE `adm_files`
  MODIFY `fil_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adm_folders`
--
ALTER TABLE `adm_folders`
  MODIFY `fol_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `adm_guestbook`
--
ALTER TABLE `adm_guestbook`
  MODIFY `gbo_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adm_guestbook_comments`
--
ALTER TABLE `adm_guestbook_comments`
  MODIFY `gbc_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adm_invent`
--
ALTER TABLE `adm_invent`
  MODIFY `inv_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adm_invent_data`
--
ALTER TABLE `adm_invent_data`
  MODIFY `ind_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adm_invent_fields`
--
ALTER TABLE `adm_invent_fields`
  MODIFY `inf_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `adm_links`
--
ALTER TABLE `adm_links`
  MODIFY `lnk_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adm_lists`
--
ALTER TABLE `adm_lists`
  MODIFY `lst_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `adm_list_columns`
--
ALTER TABLE `adm_list_columns`
  MODIFY `lsc_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `adm_members`
--
ALTER TABLE `adm_members`
  MODIFY `mem_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `adm_messages`
--
ALTER TABLE `adm_messages`
  MODIFY `msg_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adm_messages_content`
--
ALTER TABLE `adm_messages_content`
  MODIFY `msc_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adm_organizations`
--
ALTER TABLE `adm_organizations`
  MODIFY `org_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `adm_photos`
--
ALTER TABLE `adm_photos`
  MODIFY `pho_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adm_preferences`
--
ALTER TABLE `adm_preferences`
  MODIFY `prf_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;
--
-- AUTO_INCREMENT for table `adm_registrations`
--
ALTER TABLE `adm_registrations`
  MODIFY `reg_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `adm_roles`
--
ALTER TABLE `adm_roles`
  MODIFY `rol_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `adm_roles_rights`
--
ALTER TABLE `adm_roles_rights`
  MODIFY `ror_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `adm_roles_rights_data`
--
ALTER TABLE `adm_roles_rights_data`
  MODIFY `rrd_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adm_rooms`
--
ALTER TABLE `adm_rooms`
  MODIFY `room_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `adm_sessions`
--
ALTER TABLE `adm_sessions`
  MODIFY `ses_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `adm_texts`
--
ALTER TABLE `adm_texts`
  MODIFY `txt_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `adm_users`
--
ALTER TABLE `adm_users`
  MODIFY `usr_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `adm_user_data`
--
ALTER TABLE `adm_user_data`
  MODIFY `usd_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `adm_user_fields`
--
ALTER TABLE `adm_user_fields`
  MODIFY `usf_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `adm_user_log`
--
ALTER TABLE `adm_user_log`
  MODIFY `usl_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adm_user_relations`
--
ALTER TABLE `adm_user_relations`
  MODIFY `ure_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `adm_user_relation_types`
--
ALTER TABLE `adm_user_relation_types`
  MODIFY `urt_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `api_access`
--
ALTER TABLE `api_access`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `api_keys`
--
ALTER TABLE `api_keys`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `api_limits`
--
ALTER TABLE `api_limits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `api_logs`
--
ALTER TABLE `api_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `adm_announcements`
--
ALTER TABLE `adm_announcements`
  ADD CONSTRAINT `adm_FK_ANN_USR_CHANGE` FOREIGN KEY (`ann_usr_id_change`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_auto_login`
--
ALTER TABLE `adm_auto_login`
  ADD CONSTRAINT `adm_FK_ATL_ORG` FOREIGN KEY (`atl_org_id`) REFERENCES `adm_organizations` (`org_id`),
  ADD CONSTRAINT `adm_FK_ATL_USR` FOREIGN KEY (`atl_usr_id`) REFERENCES `adm_users` (`usr_id`);

--
-- Constraints for table `adm_categories`
--
ALTER TABLE `adm_categories`
  ADD CONSTRAINT `adm_FK_CAT_ORG` FOREIGN KEY (`cat_org_id`) REFERENCES `adm_organizations` (`org_id`),
  ADD CONSTRAINT `adm_FK_CAT_USR_CHANGE` FOREIGN KEY (`cat_usr_id_change`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `adm_FK_CAT_USR_CREATE` FOREIGN KEY (`cat_usr_id_create`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_dates`
--
ALTER TABLE `adm_dates`
  ADD CONSTRAINT `adm_FK_DAT_CAT` FOREIGN KEY (`dat_cat_id`) REFERENCES `adm_categories` (`cat_id`),
  ADD CONSTRAINT `adm_FK_DAT_ROL` FOREIGN KEY (`dat_rol_id`) REFERENCES `adm_roles` (`rol_id`),
  ADD CONSTRAINT `adm_FK_DAT_ROOM` FOREIGN KEY (`dat_room_id`) REFERENCES `adm_rooms` (`room_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `adm_FK_DAT_USR_CHANGE` FOREIGN KEY (`dat_usr_id_change`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `adm_FK_DAT_USR_CREATE` FOREIGN KEY (`dat_usr_id_create`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_date_role`
--
ALTER TABLE `adm_date_role`
  ADD CONSTRAINT `adm_FK_DTR_DAT` FOREIGN KEY (`dtr_dat_id`) REFERENCES `adm_dates` (`dat_id`),
  ADD CONSTRAINT `adm_FK_DTR_ROL` FOREIGN KEY (`dtr_rol_id`) REFERENCES `adm_roles` (`rol_id`);

--
-- Constraints for table `adm_files`
--
ALTER TABLE `adm_files`
  ADD CONSTRAINT `adm_FK_FIL_FOL` FOREIGN KEY (`fil_fol_id`) REFERENCES `adm_folders` (`fol_id`),
  ADD CONSTRAINT `adm_FK_FIL_USR` FOREIGN KEY (`fil_usr_id`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_folders`
--
ALTER TABLE `adm_folders`
  ADD CONSTRAINT `adm_FK_FOL_FOL_PARENT` FOREIGN KEY (`fol_fol_id_parent`) REFERENCES `adm_folders` (`fol_id`),
  ADD CONSTRAINT `adm_FK_FOL_ORG` FOREIGN KEY (`fol_org_id`) REFERENCES `adm_organizations` (`org_id`),
  ADD CONSTRAINT `adm_FK_FOL_USR` FOREIGN KEY (`fol_usr_id`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_guestbook`
--
ALTER TABLE `adm_guestbook`
  ADD CONSTRAINT `adm_FK_GBO_ORG` FOREIGN KEY (`gbo_org_id`) REFERENCES `adm_organizations` (`org_id`),
  ADD CONSTRAINT `adm_FK_GBO_USR_CHANGE` FOREIGN KEY (`gbo_usr_id_change`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `adm_FK_GBO_USR_CREATE` FOREIGN KEY (`gbo_usr_id_create`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_guestbook_comments`
--
ALTER TABLE `adm_guestbook_comments`
  ADD CONSTRAINT `adm_FK_GBC_GBO` FOREIGN KEY (`gbc_gbo_id`) REFERENCES `adm_guestbook` (`gbo_id`),
  ADD CONSTRAINT `adm_FK_GBC_USR_CHANGE` FOREIGN KEY (`gbc_usr_id_change`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `adm_FK_GBC_USR_CREATE` FOREIGN KEY (`gbc_usr_id_create`) REFERENCES `adm_users` (`usr_id`);

--
-- Constraints for table `adm_ids`
--
ALTER TABLE `adm_ids`
  ADD CONSTRAINT `adm_FK_IDS_USR_ID` FOREIGN KEY (`ids_usr_id`) REFERENCES `adm_users` (`usr_id`);

--
-- Constraints for table `adm_links`
--
ALTER TABLE `adm_links`
  ADD CONSTRAINT `adm_FK_LNK_CAT` FOREIGN KEY (`lnk_cat_id`) REFERENCES `adm_categories` (`cat_id`),
  ADD CONSTRAINT `adm_FK_LNK_USR_CHANGE` FOREIGN KEY (`lnk_usr_id_change`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `adm_FK_LNK_USR_CREATE` FOREIGN KEY (`lnk_usr_id_create`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_lists`
--
ALTER TABLE `adm_lists`
  ADD CONSTRAINT `adm_FK_LST_ORG` FOREIGN KEY (`lst_org_id`) REFERENCES `adm_organizations` (`org_id`),
  ADD CONSTRAINT `adm_FK_LST_USR` FOREIGN KEY (`lst_usr_id`) REFERENCES `adm_users` (`usr_id`);

--
-- Constraints for table `adm_list_columns`
--
ALTER TABLE `adm_list_columns`
  ADD CONSTRAINT `adm_FK_LSC_LST` FOREIGN KEY (`lsc_lst_id`) REFERENCES `adm_lists` (`lst_id`),
  ADD CONSTRAINT `adm_FK_LSC_USF` FOREIGN KEY (`lsc_usf_id`) REFERENCES `adm_user_fields` (`usf_id`);

--
-- Constraints for table `adm_members`
--
ALTER TABLE `adm_members`
  ADD CONSTRAINT `adm_FK_MEM_ROL` FOREIGN KEY (`mem_rol_id`) REFERENCES `adm_roles` (`rol_id`),
  ADD CONSTRAINT `adm_FK_MEM_USR` FOREIGN KEY (`mem_usr_id`) REFERENCES `adm_users` (`usr_id`),
  ADD CONSTRAINT `adm_FK_MEM_USR_CHANGE` FOREIGN KEY (`mem_usr_id_change`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `adm_FK_MEM_USR_CREATE` FOREIGN KEY (`mem_usr_id_create`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_messages`
--
ALTER TABLE `adm_messages`
  ADD CONSTRAINT `adm_FK_MSG_USR_SENDER` FOREIGN KEY (`msg_usr_id_sender`) REFERENCES `adm_users` (`usr_id`);

--
-- Constraints for table `adm_messages_content`
--
ALTER TABLE `adm_messages_content`
  ADD CONSTRAINT `adm_FK_MSC_MSG_ID` FOREIGN KEY (`msc_msg_id`) REFERENCES `adm_messages` (`msg_id`),
  ADD CONSTRAINT `adm_FK_MSC_USR_ID` FOREIGN KEY (`msc_usr_id`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_organizations`
--
ALTER TABLE `adm_organizations`
  ADD CONSTRAINT `adm_FK_ORG_ORG_PARENT` FOREIGN KEY (`org_org_id_parent`) REFERENCES `adm_organizations` (`org_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_photos`
--
ALTER TABLE `adm_photos`
  ADD CONSTRAINT `adm_FK_PHO_ORG` FOREIGN KEY (`pho_org_id`) REFERENCES `adm_organizations` (`org_id`),
  ADD CONSTRAINT `adm_FK_PHO_PHO_PARENT` FOREIGN KEY (`pho_pho_id_parent`) REFERENCES `adm_photos` (`pho_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `adm_FK_PHO_USR_CHANGE` FOREIGN KEY (`pho_usr_id_change`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `adm_FK_PHO_USR_CREATE` FOREIGN KEY (`pho_usr_id_create`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_preferences`
--
ALTER TABLE `adm_preferences`
  ADD CONSTRAINT `adm_FK_PRF_ORG` FOREIGN KEY (`prf_org_id`) REFERENCES `adm_organizations` (`org_id`);

--
-- Constraints for table `adm_registrations`
--
ALTER TABLE `adm_registrations`
  ADD CONSTRAINT `adm_FK_REG_ORG` FOREIGN KEY (`reg_org_id`) REFERENCES `adm_organizations` (`org_id`),
  ADD CONSTRAINT `adm_FK_REG_USR` FOREIGN KEY (`reg_usr_id`) REFERENCES `adm_users` (`usr_id`);

--
-- Constraints for table `adm_roles`
--
ALTER TABLE `adm_roles`
  ADD CONSTRAINT `adm_FK_ROL_CAT` FOREIGN KEY (`rol_cat_id`) REFERENCES `adm_categories` (`cat_id`),
  ADD CONSTRAINT `adm_FK_ROL_LST_ID` FOREIGN KEY (`rol_lst_id`) REFERENCES `adm_lists` (`lst_id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `adm_FK_ROL_USR_CHANGE` FOREIGN KEY (`rol_usr_id_change`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `adm_FK_ROL_USR_CREATE` FOREIGN KEY (`rol_usr_id_create`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_roles_rights_data`
--
ALTER TABLE `adm_roles_rights_data`
  ADD CONSTRAINT `adm_FK_RRD_ROL` FOREIGN KEY (`rrd_rol_id`) REFERENCES `adm_roles` (`rol_id`),
  ADD CONSTRAINT `adm_FK_RRD_ROR` FOREIGN KEY (`rrd_ror_id`) REFERENCES `adm_roles_rights` (`ror_id`),
  ADD CONSTRAINT `adm_FK_RRD_USR_CREATE` FOREIGN KEY (`rrd_usr_id_create`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_role_dependencies`
--
ALTER TABLE `adm_role_dependencies`
  ADD CONSTRAINT `adm_FK_RLD_ROL_CHILD` FOREIGN KEY (`rld_rol_id_child`) REFERENCES `adm_roles` (`rol_id`),
  ADD CONSTRAINT `adm_FK_RLD_ROL_PARENT` FOREIGN KEY (`rld_rol_id_parent`) REFERENCES `adm_roles` (`rol_id`),
  ADD CONSTRAINT `adm_FK_RLD_USR` FOREIGN KEY (`rld_usr_id`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_rooms`
--
ALTER TABLE `adm_rooms`
  ADD CONSTRAINT `adm_FK_ROOM_USR_CHANGE` FOREIGN KEY (`room_usr_id_change`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `adm_FK_ROOM_USR_CREATE` FOREIGN KEY (`room_usr_id_create`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_sessions`
--
ALTER TABLE `adm_sessions`
  ADD CONSTRAINT `adm_FK_SES_ORG` FOREIGN KEY (`ses_org_id`) REFERENCES `adm_organizations` (`org_id`),
  ADD CONSTRAINT `adm_FK_SES_USR` FOREIGN KEY (`ses_usr_id`) REFERENCES `adm_users` (`usr_id`);

--
-- Constraints for table `adm_texts`
--
ALTER TABLE `adm_texts`
  ADD CONSTRAINT `adm_FK_TXT_ORG` FOREIGN KEY (`txt_org_id`) REFERENCES `adm_organizations` (`org_id`);

--
-- Constraints for table `adm_users`
--
ALTER TABLE `adm_users`
  ADD CONSTRAINT `adm_FK_USR_USR_CHANGE` FOREIGN KEY (`usr_usr_id_change`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `adm_FK_USR_USR_CREATE` FOREIGN KEY (`usr_usr_id_create`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_user_data`
--
ALTER TABLE `adm_user_data`
  ADD CONSTRAINT `adm_FK_USD_USF` FOREIGN KEY (`usd_usf_id`) REFERENCES `adm_user_fields` (`usf_id`),
  ADD CONSTRAINT `adm_FK_USD_USR` FOREIGN KEY (`usd_usr_id`) REFERENCES `adm_users` (`usr_id`);

--
-- Constraints for table `adm_user_fields`
--
ALTER TABLE `adm_user_fields`
  ADD CONSTRAINT `adm_FK_USF_CAT` FOREIGN KEY (`usf_cat_id`) REFERENCES `adm_categories` (`cat_id`),
  ADD CONSTRAINT `adm_FK_USF_USR_CHANGE` FOREIGN KEY (`usf_usr_id_change`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `adm_FK_USF_USR_CREATE` FOREIGN KEY (`usf_usr_id_create`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_user_log`
--
ALTER TABLE `adm_user_log`
  ADD CONSTRAINT `adm_FK_USER_LOG_1` FOREIGN KEY (`usl_usr_id`) REFERENCES `adm_users` (`usr_id`),
  ADD CONSTRAINT `adm_FK_USER_LOG_2` FOREIGN KEY (`usl_usr_id_create`) REFERENCES `adm_users` (`usr_id`),
  ADD CONSTRAINT `adm_FK_USER_LOG_3` FOREIGN KEY (`usl_usf_id`) REFERENCES `adm_user_fields` (`usf_id`);

--
-- Constraints for table `adm_user_relations`
--
ALTER TABLE `adm_user_relations`
  ADD CONSTRAINT `adm_FK_URE_URT` FOREIGN KEY (`ure_urt_id`) REFERENCES `adm_user_relation_types` (`urt_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `adm_FK_URE_USR1` FOREIGN KEY (`ure_usr_id1`) REFERENCES `adm_users` (`usr_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `adm_FK_URE_USR2` FOREIGN KEY (`ure_usr_id2`) REFERENCES `adm_users` (`usr_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `adm_FK_URE_USR_CHANGE` FOREIGN KEY (`ure_usr_id_change`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `adm_FK_URE_USR_CREATE` FOREIGN KEY (`ure_usr_id_create`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;

--
-- Constraints for table `adm_user_relation_types`
--
ALTER TABLE `adm_user_relation_types`
  ADD CONSTRAINT `adm_FK_URT_ID_INVERSE` FOREIGN KEY (`urt_id_inverse`) REFERENCES `adm_user_relation_types` (`urt_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `adm_FK_URT_USR_CHANGE` FOREIGN KEY (`urt_usr_id_change`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `adm_FK_URT_USR_CREATE` FOREIGN KEY (`urt_usr_id_create`) REFERENCES `adm_users` (`usr_id`) ON DELETE SET NULL;
